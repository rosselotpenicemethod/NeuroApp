import { PropsWithChildren } from "react";
import { ScrollView, StyleSheet, View, ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { theme } from "../utils/theme";

type ScreenShellProps = PropsWithChildren<{
  scroll?: boolean;
  contentStyle?: ViewStyle;
}>;

export function ScreenShell({ children, scroll = true, contentStyle }: ScreenShellProps) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <LinearGradient colors={["#050505", "#080806", "#050505"]} style={StyleSheet.absoluteFill} />
      {scroll ? (
        <ScrollView style={styles.container} contentContainerStyle={[styles.content, contentStyle]}>
          {children}
        </ScrollView>
      ) : (
        <View style={styles.container}>
          <View style={[styles.content, styles.flex, contentStyle]}>{children}</View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: theme.colors.background
  },
  container: {
    flex: 1
  },
  content: {
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.lg
  },
  flex: {
    flex: 1
  }
});
