import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useEffect, useMemo, useRef, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { AppButton } from "../components/AppButton";
import { MetricCard } from "../components/MetricCard";
import { RootStackParamList } from "../navigation/types";
import { average, scoreFromAccuracySpeed } from "../utils/cognitive";
import { theme } from "../utils/theme";
import { GameFrame } from "./GameFrame";
import { GameSummary } from "./GameSummary";
import { useSessionRecorder } from "./useSessionRecorder";

type Props = NativeStackScreenProps<RootStackParamList, "MemoryGame">;

const MAX_TRIALS = 24;

export function MemoryGame({ navigation }: Props) {
  const { result, saved, saveError, completeSession, resetSession } = useSessionRecorder();
  const [running, setRunning] = useState(false);
  const [trialIndex, setTrialIndex] = useState(0);
  const [position, setPosition] = useState(4);
  const [span, setSpan] = useState(1);
  const [hits, setHits] = useState(0);
  const [errors, setErrors] = useState(0);
  const [highestSpan, setHighestSpan] = useState(1);
  const history = useRef<number[]>([]);
  const latencies = useRef<number[]>([]);
  const recentCorrect = useRef<boolean[]>([]);
  const startedAt = useRef(Date.now());
  const completedRef = useRef(false);

  const isMatch = useMemo(() => history.current.length > span && position === history.current[history.current.length - 1 - span], [
    position,
    span,
    trialIndex
  ]);

  const finish = async () => {
    if (completedRef.current) {
      return;
    }
    completedRef.current = true;
    setRunning(false);
    const total = hits + errors || 1;
    const accuracy = hits / total;
    const reactionTimeMs = average(latencies.current) || 1100;
    const consistency = average(recentCorrect.current.map((item) => (item ? 100 : 0)));
    await completeSession({
      category: "memory",
      categoryLabel: "Memoria",
      score: scoreFromAccuracySpeed(accuracy, reactionTimeMs, Math.max(0, 3 - highestSpan) * 2),
      reactionTimeMs,
      errors,
      accuracy,
      metrics: {
        hits,
        spanReached: highestSpan,
        consistency
      }
    });
  };

  const nextStimulus = () => {
    if (trialIndex >= MAX_TRIALS) {
      void finish();
      return;
    }

    const shouldMatch = history.current.length >= span && Math.random() > 0.62;
    const next = shouldMatch ? history.current[history.current.length - span] : Math.floor(Math.random() * 9);
    history.current.push(next);
    setPosition(next);
    startedAt.current = Date.now();
  };

  useEffect(() => {
    if (running && !result) {
      nextStimulus();
    }
  }, [running, trialIndex, span, result]);

  const start = () => {
    resetSession();
    completedRef.current = false;
    history.current = [];
    latencies.current = [];
    recentCorrect.current = [];
    setTrialIndex(0);
    setSpan(1);
    setHighestSpan(1);
    setHits(0);
    setErrors(0);
    setRunning(true);
  };

  const answer = (matchAnswer: boolean) => {
    if (!running) {
      return;
    }
    const correct = matchAnswer === isMatch;
    latencies.current.push(Date.now() - startedAt.current);
    recentCorrect.current.push(correct);
    if (recentCorrect.current.length > 8) {
      recentCorrect.current.shift();
    }
    if (correct) {
      setHits((value) => value + 1);
    } else {
      setErrors((value) => value + 1);
    }

    if ((trialIndex + 1) % 8 === 0 && average(recentCorrect.current.map((item) => (item ? 1 : 0))) >= 0.65) {
      setSpan((value) => {
        const next = Math.min(value + 1, 3);
        setHighestSpan((current) => Math.max(current, next));
        return next;
      });
    }
    setTrialIndex((value) => value + 1);
  };

  if (result) {
    return (
      <GameFrame title="Memoria" subtitle="N-back visual simplificado" onBack={() => navigation.goBack()}>
        <GameSummary result={result} saved={saved} saveError={saveError} onRestart={start} onDashboard={() => navigation.navigate("Dashboard")} />
      </GameFrame>
    );
  }

  return (
    <GameFrame title="Memoria" subtitle={`Detecta si coincide con ${span}-back`} onBack={() => navigation.goBack()}>
      <View style={styles.metrics}>
        <MetricCard label="Trial" value={`${Math.min(trialIndex + 1, MAX_TRIALS)}/${MAX_TRIALS}`} />
        <MetricCard label="Span" value={span} tone={theme.colors.green} />
        <MetricCard label="Aciertos" value={hits} tone={theme.colors.success} />
      </View>

      <View style={styles.grid}>
        {Array.from({ length: 9 }).map((_, index) => (
          <Pressable key={index} style={[styles.cell, position === index && styles.activeCell]} />
        ))}
      </View>

      <View style={styles.actions}>
        {!running ? (
          <AppButton title="Iniciar secuencia" icon="play-outline" onPress={start} />
        ) : (
          <>
            <AppButton title="Coincide" icon="checkmark-outline" onPress={() => answer(true)} />
            <AppButton title="No coincide" icon="close-outline" variant="ghost" onPress={() => answer(false)} />
          </>
        )}
      </View>
    </GameFrame>
  );
}

const styles = StyleSheet.create({
  metrics: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.lg
  },
  grid: {
    aspectRatio: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.sm
  },
  cell: {
    width: "31.7%",
    aspectRatio: 1,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.line
  },
  activeCell: {
    backgroundColor: "#2F2716",
    borderColor: theme.colors.gold
  },
  actions: {
    marginTop: theme.spacing.lg,
    gap: theme.spacing.md
  }
});
