import { ActivityIndicator, Pressable, StyleSheet, Text, ViewStyle } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { theme } from "../utils/theme";

type AppButtonProps = {
  title: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  loading?: boolean;
  disabled?: boolean;
  variant?: "primary" | "ghost" | "danger";
  style?: ViewStyle;
};

export function AppButton({ title, onPress, icon, loading, disabled, variant = "primary", style }: AppButtonProps) {
  const isDisabled = disabled || loading;
  return (
    <Pressable
      accessibilityRole="button"
      disabled={isDisabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.base,
        styles[variant],
        isDisabled && styles.disabled,
        pressed && !isDisabled && styles.pressed,
        style
      ]}
    >
      {loading ? (
        <ActivityIndicator color={variant === "primary" ? theme.colors.background : theme.colors.gold} />
      ) : (
        <>
          {icon ? (
            <Ionicons
              name={icon}
              size={18}
              color={variant === "primary" ? theme.colors.background : theme.colors.gold}
            />
          ) : null}
          <Text style={[styles.text, variant !== "primary" && styles.textGhost]} numberOfLines={1}>
            {title}
          </Text>
        </>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    height: 52,
    borderRadius: theme.radius.md,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: theme.spacing.sm,
    paddingHorizontal: theme.spacing.lg
  },
  primary: {
    backgroundColor: theme.colors.gold
  },
  ghost: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: theme.colors.lineStrong
  },
  danger: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: theme.colors.danger
  },
  pressed: {
    transform: [{ scale: 0.985 }],
    opacity: 0.86
  },
  disabled: {
    opacity: 0.48
  },
  text: {
    color: theme.colors.background,
    fontSize: 15,
    fontWeight: "800"
  },
  textGhost: {
    color: theme.colors.gold
  }
});
