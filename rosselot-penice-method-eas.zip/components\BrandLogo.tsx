import { Image, StyleSheet, Text, View } from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { theme } from "../utils/theme";

const brandLogo = require("../assets/logo/rosselot-penice-full-color.png");

export function BrandLogo() {
  return (
    <Animated.View entering={FadeInDown.duration(650)} style={styles.container}>
      <View style={styles.logoPlate}>
        <Image source={brandLogo} style={styles.logo} resizeMode="contain" />
      </View>
      <Text style={styles.subtitle}>Neurocognitive Performance System</Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    gap: theme.spacing.md,
    width: "100%"
  },
  logoPlate: {
    width: "100%",
    maxWidth: 320,
    aspectRatio: 1.62,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.lineStrong,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    overflow: "hidden",
    padding: theme.spacing.md
  },
  logo: {
    width: "100%",
    height: "100%"
  },
  subtitle: {
    color: theme.colors.gold,
    fontSize: 12,
    fontWeight: "600",
    textAlign: "center"
  }
});
