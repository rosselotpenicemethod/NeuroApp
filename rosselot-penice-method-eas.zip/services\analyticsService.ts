import {
  addDoc,
  collection,
  DocumentData,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  Timestamp
} from "firebase/firestore";
import { db } from "../firebase/firebaseConfig";
import { GameSessionResult, StoredGameSession } from "../utils/types";

type FirestoreSession = Omit<GameSessionResult, "createdAt"> & {
  createdAt?: Timestamp;
  createdAtClient: string;
};

export const saveGameSession = async (uid: string, result: GameSessionResult) => {
  const payload: DocumentData = {
    ...result,
    createdAt: serverTimestamp(),
    createdAtClient: result.createdAt.toISOString()
  };

  await addDoc(collection(db, "users", uid, "sessions"), payload);
};

export const fetchUserSessions = async (uid: string, maxSessions = 100): Promise<StoredGameSession[]> => {
  const sessionsQuery = query(collection(db, "users", uid, "sessions"), orderBy("createdAt", "desc"), limit(maxSessions));
  const snapshot = await getDocs(sessionsQuery);

  return snapshot.docs.map((document) => {
    const data = document.data() as FirestoreSession;
    const createdAt = data.createdAt?.toDate() ?? new Date(data.createdAtClient);
    return {
      id: document.id,
      ...data,
      createdAt
    };
  });
};
