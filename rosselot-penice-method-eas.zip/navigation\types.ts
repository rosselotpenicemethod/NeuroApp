import { CognitiveCategoryId } from "../utils/types";

export type RootStackParamList = {
  Login: undefined;
  Dashboard: undefined;
  DividedAttentionGame: undefined;
  ConcentrationGame: undefined;
  MemoryGame: undefined;
  SelectiveAttentionGame: undefined;
  ProblemSolvingGame: undefined;
  Analytics: {
    focusCategory?: CognitiveCategoryId;
  } | undefined;
};
