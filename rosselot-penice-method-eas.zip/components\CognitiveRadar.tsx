import { Fragment } from "react";
import Svg, { Circle, Line, Polygon, Text as SvgText } from "react-native-svg";
import { StyleSheet, View } from "react-native";
import { theme } from "../utils/theme";
import { RadarPoint } from "../utils/types";

type CognitiveRadarProps = {
  points: RadarPoint[];
  size?: number;
};

const polar = (center: number, radius: number, angle: number) => {
  const radians = (angle - 90) * (Math.PI / 180);
  return {
    x: center + radius * Math.cos(radians),
    y: center + radius * Math.sin(radians)
  };
};

export function CognitiveRadar({ points, size = 260 }: CognitiveRadarProps) {
  const center = size / 2;
  const radius = size * 0.32;
  const sides = Math.max(points.length, 3);
  const polygon = points
    .map((point, index) => {
      const position = polar(center, radius * (point.value / 100), (360 / sides) * index);
      return `${position.x},${position.y}`;
    })
    .join(" ");

  return (
    <View style={styles.wrapper}>
      <Svg width={size} height={size}>
        {[0.33, 0.66, 1].map((scale) => (
          <Circle
            key={scale}
            cx={center}
            cy={center}
            r={radius * scale}
            stroke={theme.colors.lineStrong}
            strokeWidth={1}
            fill="transparent"
          />
        ))}
        {points.map((point, index) => {
          const angle = (360 / sides) * index;
          const edge = polar(center, radius, angle);
          const label = polar(center, radius + 30, angle);
          return (
            <Fragment key={point.category}>
              <Line x1={center} y1={center} x2={edge.x} y2={edge.y} stroke={theme.colors.line} strokeWidth={1} />
              <SvgText
                x={label.x}
                y={label.y}
                fill={theme.colors.textMuted}
                fontSize={10}
                fontWeight="700"
                textAnchor="middle"
              >
                {point.label}
              </SvgText>
            </Fragment>
          );
        })}
        <Polygon points={polygon} fill="rgba(216,179,95,0.28)" stroke={theme.colors.gold} strokeWidth={2} />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: "center",
    justifyContent: "center"
  }
});
