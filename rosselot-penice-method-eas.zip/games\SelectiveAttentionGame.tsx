import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useEffect, useMemo, useRef, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { AppButton } from "../components/AppButton";
import { MetricCard } from "../components/MetricCard";
import { RootStackParamList } from "../navigation/types";
import { average, clamp, scoreFromAccuracySpeed } from "../utils/cognitive";
import { theme } from "../utils/theme";
import { GameFrame } from "./GameFrame";
import { GameSummary } from "./GameSummary";
import { useSessionRecorder } from "./useSessionRecorder";

type Props = NativeStackScreenProps<RootStackParamList, "SelectiveAttentionGame">;

type StimulusItem = {
  id: string;
  shape: "circle" | "square" | "diamond";
  color: string;
  isTarget: boolean;
};

const MAX_TRIALS = 16;
const COLORS = [theme.colors.blue, theme.colors.green, theme.colors.red, theme.colors.violet, theme.colors.textMuted];
const SHAPES: StimulusItem["shape"][] = ["circle", "square", "diamond"];

export function SelectiveAttentionGame({ navigation }: Props) {
  const { result, saved, saveError, completeSession, resetSession } = useSessionRecorder();
  const [running, setRunning] = useState(false);
  const [trialIndex, setTrialIndex] = useState(0);
  const [hits, setHits] = useState(0);
  const [falseTaps, setFalseTaps] = useState(0);
  const [items, setItems] = useState<StimulusItem[]>([]);
  const latencies = useRef<number[]>([]);
  const startedAt = useRef(Date.now());
  const completedRef = useRef(false);

  const generateItems = () => {
    const targetIndex = Math.floor(Math.random() * 12);
    const nextItems = Array.from({ length: 12 }).map((_, index) => {
      const isTarget = index === targetIndex;
      return {
        id: `${trialIndex}-${index}`,
        shape: isTarget ? "diamond" : SHAPES[Math.floor(Math.random() * SHAPES.length)],
        color: isTarget ? theme.colors.gold : COLORS[Math.floor(Math.random() * COLORS.length)],
        isTarget
      };
    });
    setItems(nextItems);
    startedAt.current = Date.now();
  };

  const finish = async () => {
    if (completedRef.current) {
      return;
    }
    completedRef.current = true;
    setRunning(false);
    const accuracy = hits / MAX_TRIALS;
    const inhibition = clamp(100 - falseTaps * 8, 0, 100);
    const reactionTimeMs = average(latencies.current) || 1000;
    await completeSession({
      category: "selective-attention",
      categoryLabel: "Atencion Selectiva",
      score: scoreFromAccuracySpeed(accuracy, reactionTimeMs, falseTaps * 2),
      reactionTimeMs,
      errors: falseTaps + (MAX_TRIALS - hits),
      accuracy,
      metrics: {
        inhibition,
        selectiveAccuracy: accuracy * 100,
        discriminativeSpeed: reactionTimeMs
      }
    });
  };

  useEffect(() => {
    if (!running || result) {
      return;
    }
    if (trialIndex >= MAX_TRIALS) {
      void finish();
      return undefined;
    }
    generateItems();
    const timeout = setTimeout(() => {
      setTrialIndex((value) => value + 1);
    }, 2600);
    return () => clearTimeout(timeout);
  }, [running, trialIndex, result]);

  const start = () => {
    resetSession();
    completedRef.current = false;
    latencies.current = [];
    setTrialIndex(0);
    setHits(0);
    setFalseTaps(0);
    setRunning(true);
  };

  const pressItem = (item: StimulusItem) => {
    if (!running) {
      return;
    }
    if (item.isTarget) {
      latencies.current.push(Date.now() - startedAt.current);
      setHits((value) => value + 1);
      setTrialIndex((value) => value + 1);
    } else {
      setFalseTaps((value) => value + 1);
    }
  };

  const inhibition = useMemo(() => clamp(100 - falseTaps * 8, 0, 100), [falseTaps]);

  if (result) {
    return (
      <GameFrame title="Atencion Selectiva" subtitle="Ignora interferencias y detecta target" onBack={() => navigation.goBack()}>
        <GameSummary result={result} saved={saved} saveError={saveError} onRestart={start} onDashboard={() => navigation.navigate("Dashboard")} />
      </GameFrame>
    );
  }

  return (
    <GameFrame title="Atencion Selectiva" subtitle="Toca solo el diamante dorado" onBack={() => navigation.goBack()}>
      <View style={styles.metrics}>
        <MetricCard label="Trial" value={`${Math.min(trialIndex + 1, MAX_TRIALS)}/${MAX_TRIALS}`} />
        <MetricCard label="Inhibicion" value={`${inhibition}%`} tone={theme.colors.violet} />
        <MetricCard label="Falsos taps" value={falseTaps} tone={theme.colors.danger} />
      </View>

      <View style={styles.grid}>
        {items.map((item) => (
          <Pressable key={item.id} onPress={() => pressItem(item)} style={styles.cell}>
            <View
              style={[
                styles.shape,
                item.shape === "circle" && styles.circle,
                item.shape === "diamond" && styles.diamond,
                { backgroundColor: item.color }
              ]}
            />
          </Pressable>
        ))}
      </View>

      {!running ? (
        <View style={styles.start}>
          <AppButton title="Iniciar filtro" icon="play-outline" onPress={start} />
        </View>
      ) : (
        <Text style={styles.caption}>Target: diamante dorado. Distractores: forma o color parcial.</Text>
      )}
    </GameFrame>
  );
}

const styles = StyleSheet.create({
  metrics: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.lg
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.sm
  },
  cell: {
    width: "31.7%",
    aspectRatio: 1,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.line,
    backgroundColor: theme.colors.surface,
    alignItems: "center",
    justifyContent: "center"
  },
  shape: {
    width: 34,
    height: 34,
    borderRadius: 4
  },
  circle: {
    borderRadius: 17
  },
  diamond: {
    transform: [{ rotate: "45deg" }]
  },
  start: {
    marginTop: theme.spacing.lg
  },
  caption: {
    color: theme.colors.textMuted,
    fontSize: 12,
    marginTop: theme.spacing.md,
    textAlign: "center"
  }
});
