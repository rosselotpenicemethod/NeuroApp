import { StyleSheet, Text, View } from "react-native";
import { theme } from "../utils/theme";

type MetricCardProps = {
  label: string;
  value: string | number;
  tone?: string;
};

export function MetricCard({ label, value, tone = theme.colors.gold }: MetricCardProps) {
  return (
    <View style={styles.card}>
      <Text style={[styles.value, { color: tone }]} numberOfLines={1}>
        {value}
      </Text>
      <Text style={styles.label} numberOfLines={2}>
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 108,
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.line,
    backgroundColor: theme.colors.surface
  },
  value: {
    fontSize: 22,
    fontWeight: "900"
  },
  label: {
    marginTop: theme.spacing.xs,
    color: theme.colors.textMuted,
    fontSize: 11,
    fontWeight: "600"
  }
});
