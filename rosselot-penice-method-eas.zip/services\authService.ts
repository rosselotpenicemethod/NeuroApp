import { sendPasswordResetEmail, signInWithEmailAndPassword, signOut, User } from "firebase/auth";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, db } from "../firebase/firebaseConfig";
import { normalizeEmail } from "../utils/validators";

export type AuthorizedProfile = {
  uid: string;
  email: string;
  displayName?: string;
  role?: "athlete" | "coach" | "admin";
};

const readAuthorization = async (user: User): Promise<AuthorizedProfile | null> => {
  const email = normalizeEmail(user.email ?? "");
  const uidAuthorization = await getDoc(doc(db, "authorizedUsers", user.uid));

  if (uidAuthorization.exists() && uidAuthorization.data().active === true) {
    const data = uidAuthorization.data();
    return {
      uid: user.uid,
      email,
      displayName: data.displayName ?? user.displayName ?? undefined,
      role: data.role ?? "athlete"
    };
  }

  const emailAuthorization = await getDoc(doc(db, "authorizedEmails", email));
  if (emailAuthorization.exists() && emailAuthorization.data().active === true) {
    const data = emailAuthorization.data();
    await setDoc(
      doc(db, "authorizedUsers", user.uid),
      {
        email,
        displayName: data.displayName ?? user.displayName ?? null,
        role: data.role ?? "athlete",
        active: true,
        linkedAt: serverTimestamp()
      },
      { merge: true }
    );
    return {
      uid: user.uid,
      email,
      displayName: data.displayName ?? user.displayName ?? undefined,
      role: data.role ?? "athlete"
    };
  }

  return null;
};

export const signInAuthorizedUser = async (email: string, password: string) => {
  const credential = await signInWithEmailAndPassword(auth, normalizeEmail(email), password);
  const profile = await readAuthorization(credential.user);

  if (!profile) {
    await signOut(auth);
    throw new Error("Usuario no autorizado para ROSSELOT PENICE METHOD.");
  }

  await setDoc(
    doc(db, "users", credential.user.uid),
    {
      email: profile.email,
      displayName: profile.displayName ?? null,
      role: profile.role ?? "athlete",
      lastLoginAt: serverTimestamp()
    },
    { merge: true }
  );

  return profile;
};

export const hydrateAuthorizedUser = async (user: User) => {
  const profile = await readAuthorization(user);
  if (!profile) {
    await signOut(auth);
  }
  return profile;
};

export const requestPasswordReset = (email: string) => sendPasswordResetEmail(auth, normalizeEmail(email));

export const signOutCurrentUser = () => signOut(auth);
