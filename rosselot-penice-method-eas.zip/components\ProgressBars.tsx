import { StyleSheet, Text, View } from "react-native";
import { theme } from "../utils/theme";
import { WeeklyPoint } from "../utils/types";

type ProgressBarsProps = {
  points: WeeklyPoint[];
};

export function ProgressBars({ points }: ProgressBarsProps) {
  return (
    <View style={styles.container}>
      {points.map((point) => (
        <View key={point.label} style={styles.item}>
          <View style={styles.track}>
            <View style={[styles.fill, { height: `${Math.max(point.score, 4)}%` }]} />
          </View>
          <Text style={styles.label}>{point.label}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 142,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: theme.spacing.sm
  },
  item: {
    flex: 1,
    alignItems: "center",
    gap: theme.spacing.sm
  },
  track: {
    height: 108,
    width: "100%",
    borderRadius: theme.radius.sm,
    justifyContent: "flex-end",
    backgroundColor: theme.colors.surface,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: theme.colors.line
  },
  fill: {
    width: "100%",
    backgroundColor: theme.colors.gold
  },
  label: {
    color: theme.colors.textMuted,
    fontSize: 10,
    fontWeight: "700"
  }
});
