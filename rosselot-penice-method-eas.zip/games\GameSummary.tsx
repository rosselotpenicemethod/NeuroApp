import { StyleSheet, Text, View } from "react-native";
import { AppButton } from "../components/AppButton";
import { MetricCard } from "../components/MetricCard";
import { theme } from "../utils/theme";
import { GameSessionResult } from "../utils/types";

type GameSummaryProps = {
  result: GameSessionResult;
  saved: boolean;
  saveError?: string | null;
  onRestart: () => void;
  onDashboard: () => void;
};

export function GameSummary({ result, saved, saveError, onRestart, onDashboard }: GameSummaryProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sesion completada</Text>
      <Text style={[styles.copy, saveError && styles.error]}>
        {saveError ? saveError : saved ? "Metricas guardadas en Firestore." : "Guardando metricas..."}
      </Text>
      <View style={styles.grid}>
        <MetricCard label="Score compuesto" value={`${result.score}/100`} />
        <MetricCard label="Precision" value={`${result.accuracy}%`} />
        <MetricCard label="Tiempo reaccion" value={`${result.reactionTimeMs} ms`} />
        <MetricCard label="Errores" value={result.errors} tone={theme.colors.danger} />
      </View>
      <View style={styles.actions}>
        <AppButton title="Repetir" icon="refresh-outline" variant="ghost" onPress={onRestart} />
        <AppButton title="Dashboard" icon="grid-outline" onPress={onDashboard} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: theme.spacing.md,
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.lineStrong,
    backgroundColor: theme.colors.surfaceElevated
  },
  title: {
    color: theme.colors.text,
    fontSize: 22,
    fontWeight: "900"
  },
  copy: {
    color: theme.colors.textMuted,
    fontSize: 13
  },
  error: {
    color: theme.colors.warning
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.md
  },
  actions: {
    gap: theme.spacing.md
  }
});
