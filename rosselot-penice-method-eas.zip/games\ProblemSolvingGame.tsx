import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useEffect, useMemo, useRef, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { AppButton } from "../components/AppButton";
import { MetricCard } from "../components/MetricCard";
import { RootStackParamList } from "../navigation/types";
import { average, scoreFromAccuracySpeed } from "../utils/cognitive";
import { theme } from "../utils/theme";
import { GameFrame } from "./GameFrame";
import { GameSummary } from "./GameSummary";
import { useSessionRecorder } from "./useSessionRecorder";

type Props = NativeStackScreenProps<RootStackParamList, "ProblemSolvingGame">;

type MatrixSymbol = {
  shape: "circle" | "square" | "diamond";
  color: string;
  size: number;
};

type Puzzle = {
  cells: (MatrixSymbol | null)[];
  options: MatrixSymbol[];
  answerIndex: number;
  level: number;
};

const SHAPES: MatrixSymbol["shape"][] = ["circle", "square", "diamond"];
const COLORS = [theme.colors.gold, theme.colors.blue, theme.colors.green];
const SIZES = [20, 28, 36];
const MAX_LEVEL = 8;

const symbolAt = (row: number, col: number, level: number): MatrixSymbol => ({
  shape: SHAPES[(row + col + level) % SHAPES.length],
  color: COLORS[(row * 2 + col + level) % COLORS.length],
  size: SIZES[(row + col * 2 + level) % SIZES.length]
});

const sameSymbol = (a: MatrixSymbol, b: MatrixSymbol) => a.shape === b.shape && a.color === b.color && a.size === b.size;

const createPuzzle = (level: number): Puzzle => {
  const cells = Array.from({ length: 9 }).map((_, index) => {
    const row = Math.floor(index / 3);
    const col = index % 3;
    return symbolAt(row, col, level);
  });
  const answer = cells[8];
  const options = [
    answer,
    symbolAt(2, 1, level + 1),
    symbolAt(1, 2, level + 2),
    symbolAt(0, 2, level + 3)
  ].sort(() => Math.random() - 0.5);
  return {
    cells: cells.map((cell, index) => (index === 8 ? null : cell)),
    options,
    answerIndex: options.findIndex((option) => sameSymbol(option, answer)),
    level
  };
};

function SymbolView({ symbol }: { symbol: MatrixSymbol }) {
  return (
    <View
      style={[
        styles.symbol,
        symbol.shape === "circle" && styles.circle,
        symbol.shape === "diamond" && styles.diamond,
        {
          width: symbol.size,
          height: symbol.size,
          backgroundColor: symbol.color
        }
      ]}
    />
  );
}

export function ProblemSolvingGame({ navigation }: Props) {
  const { result, saved, saveError, completeSession, resetSession } = useSessionRecorder();
  const [running, setRunning] = useState(false);
  const [level, setLevel] = useState(1);
  const [hits, setHits] = useState(0);
  const [errors, setErrors] = useState(0);
  const [puzzle, setPuzzle] = useState<Puzzle>(() => createPuzzle(1));
  const latencies = useRef<number[]>([]);
  const startedAt = useRef(Date.now());
  const completedRef = useRef(false);

  const finish = async () => {
    if (completedRef.current) {
      return;
    }
    completedRef.current = true;
    setRunning(false);
    const total = hits + errors || 1;
    const accuracy = hits / total;
    const reactionTimeMs = average(latencies.current) || 2400;
    await completeSession({
      category: "problem-solving",
      categoryLabel: "Resolucion de Problemas",
      score: scoreFromAccuracySpeed(accuracy, reactionTimeMs, errors * 2),
      reactionTimeMs,
      errors,
      accuracy,
      metrics: {
        solved: hits,
        levelReached: Math.min(level, MAX_LEVEL),
        resolutionTime: reactionTimeMs
      }
    });
  };

  useEffect(() => {
    if (!running || result) {
      return;
    }
    if (level > MAX_LEVEL) {
      void finish();
      return;
    }
    setPuzzle(createPuzzle(level));
    startedAt.current = Date.now();
  }, [running, level, result]);

  const start = () => {
    resetSession();
    completedRef.current = false;
    latencies.current = [];
    setLevel(1);
    setHits(0);
    setErrors(0);
    setPuzzle(createPuzzle(1));
    setRunning(true);
  };

  const answer = (index: number) => {
    if (!running) {
      return;
    }
    latencies.current.push(Date.now() - startedAt.current);
    if (index === puzzle.answerIndex) {
      setHits((value) => value + 1);
    } else {
      setErrors((value) => value + 1);
    }
    setLevel((value) => value + 1);
  };

  const accuracy = useMemo(() => Math.round((hits / Math.max(hits + errors, 1)) * 100), [errors, hits]);

  if (result) {
    return (
      <GameFrame title="Resolucion de Problemas" subtitle="Matrices abstractas progresivas" onBack={() => navigation.goBack()}>
        <GameSummary result={result} saved={saved} saveError={saveError} onRestart={start} onDashboard={() => navigation.navigate("Dashboard")} />
      </GameFrame>
    );
  }

  return (
    <GameFrame title="Resolucion de Problemas" subtitle="Elige la pieza que completa la matriz" onBack={() => navigation.goBack()}>
      <View style={styles.metrics}>
        <MetricCard label="Nivel" value={`${Math.min(level, MAX_LEVEL)}/${MAX_LEVEL}`} />
        <MetricCard label="Aciertos" value={hits} tone={theme.colors.success} />
        <MetricCard label="Precision" value={`${accuracy}%`} tone={theme.colors.gold} />
      </View>

      <View style={styles.matrix}>
        {puzzle.cells.map((cell, index) => (
          <View key={index} style={[styles.matrixCell, !cell && styles.missingCell]}>
            {cell ? <SymbolView symbol={cell} /> : <Text style={styles.question}>?</Text>}
          </View>
        ))}
      </View>

      <View style={styles.options}>
        {puzzle.options.map((option, index) => (
          <Pressable key={`${option.shape}-${option.color}-${option.size}-${index}`} style={styles.option} onPress={() => answer(index)}>
            <SymbolView symbol={option} />
          </Pressable>
        ))}
      </View>

      {!running ? (
        <View style={styles.start}>
          <AppButton title="Iniciar matrices" icon="play-outline" onPress={start} />
        </View>
      ) : null}
    </GameFrame>
  );
}

const styles = StyleSheet.create({
  metrics: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.lg
  },
  matrix: {
    aspectRatio: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.sm
  },
  matrixCell: {
    width: "31.7%",
    aspectRatio: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.line,
    backgroundColor: theme.colors.surface
  },
  missingCell: {
    borderColor: theme.colors.gold,
    backgroundColor: "#181409"
  },
  symbol: {
    borderRadius: 5
  },
  circle: {
    borderRadius: 99
  },
  diamond: {
    transform: [{ rotate: "45deg" }]
  },
  question: {
    color: theme.colors.gold,
    fontSize: 38,
    fontWeight: "900"
  },
  options: {
    flexDirection: "row",
    gap: theme.spacing.sm,
    marginTop: theme.spacing.lg
  },
  option: {
    flex: 1,
    aspectRatio: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.lineStrong,
    backgroundColor: theme.colors.surfaceElevated
  },
  start: {
    marginTop: theme.spacing.lg
  }
});
