import { useFocusEffect } from "@react-navigation/native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useCallback, useMemo, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { AppButton } from "../components/AppButton";
import { CategoryCard } from "../components/CategoryCard";
import { CognitiveRadar } from "../components/CognitiveRadar";
import { MetricCard } from "../components/MetricCard";
import { ProgressBars } from "../components/ProgressBars";
import { ScreenShell } from "../components/ScreenShell";
import { StatPill } from "../components/StatPill";
import { RootStackParamList } from "../navigation/types";
import { fetchUserSessions } from "../services/analyticsService";
import { useAuth } from "../services/AuthContext";
import {
  CATEGORIES,
  average,
  computeMonthlyProgress,
  computeRadar,
  computeWeeklyEvolution
} from "../utils/cognitive";
import { theme } from "../utils/theme";
import { CognitiveCategoryId, StoredGameSession } from "../utils/types";

type Props = NativeStackScreenProps<RootStackParamList, "Dashboard">;
type GameRouteName =
  | "DividedAttentionGame"
  | "ConcentrationGame"
  | "MemoryGame"
  | "SelectiveAttentionGame"
  | "ProblemSolvingGame";

const routeByCategory: Record<CognitiveCategoryId, GameRouteName> = {
  "divided-attention": "DividedAttentionGame",
  concentration: "ConcentrationGame",
  memory: "MemoryGame",
  "selective-attention": "SelectiveAttentionGame",
  "problem-solving": "ProblemSolvingGame"
};

export function DashboardScreen({ navigation }: Props) {
  const { profile, signOut } = useAuth();
  const [sessions, setSessions] = useState<StoredGameSession[]>([]);
  const [loading, setLoading] = useState(true);

  const loadSessions = useCallback(async () => {
    if (!profile) {
      return;
    }
    const data = await fetchUserSessions(profile.uid);
    setSessions(data);
  }, [profile]);

  useFocusEffect(
    useCallback(() => {
      let mounted = true;
      setLoading(true);
      loadSessions()
        .catch(() => {
          if (mounted) {
            setSessions([]);
          }
        })
        .finally(() => {
          if (mounted) {
            setLoading(false);
          }
        });
      return () => {
        mounted = false;
      };
    }, [loadSessions])
  );

  const weekly = useMemo(() => computeWeeklyEvolution(sessions), [sessions]);
  const radar = useMemo(() => computeRadar(sessions), [sessions]);
  const monthly = useMemo(() => computeMonthlyProgress(sessions), [sessions]);
  const personalBest = useMemo(() => Math.max(0, ...sessions.map((session) => session.score)), [sessions]);
  const globalAverage = useMemo(() => Math.round(average(sessions.map((session) => session.score))), [sessions]);

  const scoreByCategory = useMemo(() => {
    return CATEGORIES.reduce<Record<CognitiveCategoryId, number>>((accumulator, category) => {
      const categoryScores = sessions
        .filter((session) => session.category === category.id)
        .slice(0, 5)
        .map((session) => session.score);
      accumulator[category.id] = Math.round(average(categoryScores));
      return accumulator;
    }, {} as Record<CognitiveCategoryId, number>);
  }, [sessions]);

  return (
    <ScreenShell
      contentStyle={styles.content}
      scroll
    >
      <View style={styles.header}>
        <View style={styles.headerText}>
          <Text style={styles.kicker}>ROSSELOT PENICE METHOD</Text>
          <Text style={styles.title}>Centro neurocognitivo</Text>
          <Text style={styles.subtitle}>{profile?.displayName ?? profile?.email}</Text>
        </View>
        <AppButton title="Salir" icon="log-out-outline" variant="ghost" onPress={signOut} style={styles.logout} />
      </View>

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator color={theme.colors.gold} />
        </View>
      ) : (
        <View>
          <View style={styles.statRow}>
            <StatPill label="Promedio" value={`${globalAverage}/100`} />
            <StatPill label="Mejor marca" value={`${personalBest}/100`} />
            <StatPill label="Mensual" value={`${monthly}/100`} />
          </View>

          <Animated.View entering={FadeInDown.duration(450)} style={styles.analyticsBlock}>
            <View style={styles.blockHeader}>
              <Text style={styles.blockTitle}>Evolucion semanal</Text>
              <AppButton title="Analytics" icon="analytics-outline" variant="ghost" onPress={() => navigation.navigate("Analytics")} style={styles.smallButton} />
            </View>
            <ProgressBars points={weekly} />
          </Animated.View>

          <Animated.View entering={FadeInDown.delay(80).duration(450)} style={styles.analyticsBlock}>
            <Text style={styles.blockTitle}>Radar cognitivo</Text>
            <CognitiveRadar points={radar} />
          </Animated.View>

          <View style={styles.metricGrid}>
            <MetricCard label="Sesiones registradas" value={sessions.length} />
            <MetricCard
              label="Ranking personal"
              value={sessions.length ? `#${sessions.findIndex((session) => session.score === personalBest) + 1}` : "-"}
              tone={theme.colors.success}
            />
          </View>

          <View style={styles.categoryList}>
            <Text style={styles.blockTitle}>Categorias cognitivas</Text>
            {CATEGORIES.map((category) => (
              <CategoryCard
                key={category.id}
                category={category}
                score={scoreByCategory[category.id]}
                onPress={() => navigation.navigate(routeByCategory[category.id])}
              />
            ))}
          </View>
        </View>
      )}
    </ScreenShell>
  );
}

const styles = StyleSheet.create({
  content: {
    gap: theme.spacing.lg
  },
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: theme.spacing.md
  },
  headerText: {
    flex: 1
  },
  kicker: {
    color: theme.colors.gold,
    fontSize: 11,
    fontWeight: "900"
  },
  title: {
    color: theme.colors.text,
    fontSize: 28,
    fontWeight: "900",
    marginTop: theme.spacing.xs
  },
  subtitle: {
    color: theme.colors.textMuted,
    fontSize: 13,
    marginTop: theme.spacing.xs
  },
  logout: {
    width: 92,
    height: 44
  },
  loading: {
    paddingVertical: theme.spacing.xxl
  },
  statRow: {
    flexDirection: "row",
    gap: theme.spacing.sm,
    flexWrap: "wrap"
  },
  analyticsBlock: {
    marginTop: theme.spacing.lg,
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surfaceElevated,
    borderWidth: 1,
    borderColor: theme.colors.line
  },
  blockHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.md
  },
  blockTitle: {
    color: theme.colors.text,
    fontSize: theme.typography.h2,
    fontWeight: "900",
    marginBottom: theme.spacing.md
  },
  smallButton: {
    height: 38
  },
  metricGrid: {
    flexDirection: "row",
    gap: theme.spacing.md,
    marginTop: theme.spacing.lg,
    flexWrap: "wrap"
  },
  categoryList: {
    gap: theme.spacing.md,
    marginTop: theme.spacing.lg,
    paddingBottom: theme.spacing.xl
  }
});
