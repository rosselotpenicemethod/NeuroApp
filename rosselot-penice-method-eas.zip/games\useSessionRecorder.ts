import { useState } from "react";
import { saveGameSession } from "../services/analyticsService";
import { useAuth } from "../services/AuthContext";
import { buildSession } from "../utils/cognitive";
import { GameSessionResult } from "../utils/types";

export function useSessionRecorder() {
  const { profile } = useAuth();
  const [result, setResult] = useState<GameSessionResult | null>(null);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const completeSession = async (payload: Omit<GameSessionResult, "createdAt">) => {
    const session = buildSession(payload);
    setResult(session);
    setSaved(false);
    setSaveError(null);

    try {
      if (profile) {
        await saveGameSession(profile.uid, session);
      }
      setSaved(true);
    } catch (error) {
      const message = error instanceof Error ? error.message : "No se pudo guardar la sesion.";
      setSaveError(message);
    }
  };

  const resetSession = () => {
    setResult(null);
    setSaved(false);
    setSaveError(null);
  };

  return {
    result,
    saved,
    saveError,
    completeSession,
    resetSession
  };
}
