export const normalizeEmail = (email: string) => email.trim().toLowerCase();

export const validateEmail = (email: string) => {
  const normalized = normalizeEmail(email);
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized);
};

export const validatePassword = (password: string) => password.length >= 8;
