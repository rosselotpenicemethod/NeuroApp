import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useEffect, useRef, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";
import { AppButton } from "../components/AppButton";
import { MetricCard } from "../components/MetricCard";
import { RootStackParamList } from "../navigation/types";
import { average, clamp, scoreFromAccuracySpeed } from "../utils/cognitive";
import { theme } from "../utils/theme";
import { GameFrame } from "./GameFrame";
import { GameSummary } from "./GameSummary";
import { useSessionRecorder } from "./useSessionRecorder";

type Props = NativeStackScreenProps<RootStackParamList, "ConcentrationGame">;

const LETTERS = ["A", "K", "M", "T", "X", "S", "L", "X", "R"];
const MAX_TRIALS = 32;

export function ConcentrationGame({ navigation }: Props) {
  const { result, saved, saveError, completeSession, resetSession } = useSessionRecorder();
  const [running, setRunning] = useState(false);
  const [trialIndex, setTrialIndex] = useState(0);
  const [stimulus, setStimulus] = useState("X");
  const [responded, setResponded] = useState(false);
  const [hits, setHits] = useState(0);
  const [omissions, setOmissions] = useState(0);
  const [impulsivity, setImpulsivity] = useState(0);
  const [targets, setTargets] = useState(0);
  const [nonTargets, setNonTargets] = useState(0);
  const reactionTimes = useRef<number[]>([]);
  const firstHalf = useRef<number[]>([]);
  const secondHalf = useRef<number[]>([]);
  const startedAt = useRef(Date.now());
  const currentTarget = useRef(false);
  const respondedRef = useRef(false);
  const completedRef = useRef(false);

  const finish = async () => {
    if (completedRef.current) {
      return;
    }
    completedRef.current = true;
    setRunning(false);
    const evaluatedTrials = targets + nonTargets || 1;
    const accuracy = (hits + Math.max(0, nonTargets - impulsivity)) / evaluatedTrials;
    const reactionTimeMs = average(reactionTimes.current) || 950;
    const fatigueDelta = average(secondHalf.current) - average(firstHalf.current);
    const fatigue = clamp(fatigueDelta / 600, 0, 1) * 100;

    await completeSession({
      category: "concentration",
      categoryLabel: "Concentracion",
      score: scoreFromAccuracySpeed(accuracy, reactionTimeMs, omissions * 1.5 + impulsivity * 2),
      reactionTimeMs,
      errors: omissions + impulsivity,
      accuracy,
      metrics: {
        omissions,
        impulsivity,
        fatigue,
        targets
      }
    });
  };

  useEffect(() => {
    if (!running || result) {
      return undefined;
    }
    if (trialIndex >= MAX_TRIALS) {
      void finish();
      return undefined;
    }

    const nextStimulus = LETTERS[Math.floor(Math.random() * LETTERS.length)];
    const isTarget = nextStimulus === "X" && Math.random() > 0.18;
    currentTarget.current = isTarget;
    respondedRef.current = false;
    setResponded(false);
    setStimulus(isTarget ? "X" : nextStimulus === "X" ? "Z" : nextStimulus);
    startedAt.current = Date.now();

    if (isTarget) {
      setTargets((value) => value + 1);
    } else {
      setNonTargets((value) => value + 1);
    }

    const timeout = setTimeout(() => {
      if (currentTarget.current && !respondedRef.current) {
        setOmissions((value) => value + 1);
      }
      setTrialIndex((value) => value + 1);
    }, 940);
    return () => clearTimeout(timeout);
  }, [running, trialIndex, result]);

  const start = () => {
    resetSession();
    completedRef.current = false;
    reactionTimes.current = [];
    firstHalf.current = [];
    secondHalf.current = [];
    setTrialIndex(0);
    setHits(0);
    setOmissions(0);
    setImpulsivity(0);
    setTargets(0);
    setNonTargets(0);
    setRunning(true);
  };

  const respond = () => {
    if (!running || respondedRef.current) {
      return;
    }
    respondedRef.current = true;
    setResponded(true);
    if (currentTarget.current) {
      const latency = Date.now() - startedAt.current;
      reactionTimes.current.push(latency);
      if (trialIndex < MAX_TRIALS / 2) {
        firstHalf.current.push(latency);
      } else {
        secondHalf.current.push(latency);
      }
      setHits((value) => value + 1);
    } else {
      setImpulsivity((value) => value + 1);
    }
  };

  if (result) {
    return (
      <GameFrame title="Concentracion" subtitle="Sustained attention task" onBack={() => navigation.goBack()}>
        <GameSummary result={result} saved={saved} saveError={saveError} onRestart={start} onDashboard={() => navigation.navigate("Dashboard")} />
      </GameFrame>
    );
  }

  return (
    <GameFrame title="Concentracion" subtitle="Responde solo ante el estimulo X" onBack={() => navigation.goBack()}>
      <View style={styles.metrics}>
        <MetricCard label="Trial" value={`${Math.min(trialIndex + 1, MAX_TRIALS)}/${MAX_TRIALS}`} />
        <MetricCard label="Omisiones" value={omissions} tone={theme.colors.warning} />
        <MetricCard label="Impulsividad" value={impulsivity} tone={theme.colors.danger} />
      </View>

      <View style={styles.stage}>
        <Animated.Text key={`${trialIndex}-${stimulus}`} entering={FadeIn.duration(120)} style={styles.stimulus}>
          {stimulus}
        </Animated.Text>
        <Text style={styles.status}>{responded ? "Respuesta registrada" : running ? "Mantener foco" : "Listo"}</Text>
      </View>

      <View style={styles.actions}>
        {!running ? (
          <AppButton title="Iniciar protocolo" icon="play-outline" onPress={start} />
        ) : (
          <AppButton title="Responder" icon="flash-outline" onPress={respond} />
        )}
      </View>
    </GameFrame>
  );
}

const styles = StyleSheet.create({
  metrics: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.lg
  },
  stage: {
    minHeight: 260,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.lineStrong,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.colors.surface
  },
  stimulus: {
    color: theme.colors.gold,
    fontSize: 96,
    fontWeight: "900"
  },
  status: {
    color: theme.colors.textMuted,
    fontSize: 13,
    fontWeight: "700"
  },
  actions: {
    marginTop: theme.spacing.lg
  }
});
