# Assets

Coloca aqui iconos, splash screens, logos finales y recursos visuales exportados para Expo.

La primera version usa un logotipo tipografico renderizado por React Native para evitar bloquear la compilacion con binarios faltantes.
