import { onAuthStateChanged } from "firebase/auth";
import { createContext, PropsWithChildren, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { auth } from "../firebase/firebaseConfig";
import {
  AuthorizedProfile,
  hydrateAuthorizedUser,
  requestPasswordReset,
  signInAuthorizedUser,
  signOutCurrentUser
} from "./authService";

type AuthContextValue = {
  profile: AuthorizedProfile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: PropsWithChildren) {
  const [profile, setProfile] = useState<AuthorizedProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      try {
        if (!user) {
          setProfile(null);
          return;
        }
        const authorizedProfile = await hydrateAuthorizedUser(user);
        setProfile(authorizedProfile);
      } finally {
        setLoading(false);
      }
    });

    return unsubscribe;
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const authorizedProfile = await signInAuthorizedUser(email, password);
    setProfile(authorizedProfile);
  }, []);

  const resetPassword = useCallback((email: string) => requestPasswordReset(email), []);

  const signOut = useCallback(async () => {
    await signOutCurrentUser();
    setProfile(null);
  }, []);

  const value = useMemo(
    () => ({
      profile,
      loading,
      signIn,
      resetPassword,
      signOut
    }),
    [loading, profile, resetPassword, signIn, signOut]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const value = useContext(AuthContext);
  if (!value) {
    throw new Error("useAuth debe usarse dentro de AuthProvider.");
  }
  return value;
};
