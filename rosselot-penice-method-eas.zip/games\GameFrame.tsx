import { PropsWithChildren } from "react";
import { StyleSheet, Text, View } from "react-native";
import { AppButton } from "../components/AppButton";
import { ScreenShell } from "../components/ScreenShell";
import { theme } from "../utils/theme";

type GameFrameProps = PropsWithChildren<{
  title: string;
  subtitle: string;
  onBack: () => void;
}>;

export function GameFrame({ title, subtitle, onBack, children }: GameFrameProps) {
  return (
    <ScreenShell>
      <View style={styles.header}>
        <AppButton title="Volver" icon="chevron-back" variant="ghost" onPress={onBack} style={styles.back} />
        <View style={styles.titleBlock}>
          <Text style={styles.kicker}>NEUROCOGNITIVE TASK</Text>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.subtitle}>{subtitle}</Text>
        </View>
      </View>
      {children}
    </ScreenShell>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.lg
  },
  back: {
    width: 96,
    height: 42
  },
  titleBlock: {
    flex: 1
  },
  kicker: {
    color: theme.colors.gold,
    fontSize: 10,
    fontWeight: "900"
  },
  title: {
    color: theme.colors.text,
    fontSize: 24,
    fontWeight: "900",
    marginTop: 2
  },
  subtitle: {
    color: theme.colors.textMuted,
    fontSize: 12,
    marginTop: 2
  }
});
