import { Ionicons } from "@expo/vector-icons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { CognitiveCategory } from "../utils/types";
import { theme } from "../utils/theme";

type CategoryCardProps = {
  category: CognitiveCategory;
  score?: number;
  onPress: () => void;
};

export function CategoryCard({ category, score = 0, onPress }: CategoryCardProps) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
      <View style={[styles.accent, { backgroundColor: category.accent }]} />
      <View style={styles.body}>
        <View style={styles.row}>
          <Text style={styles.title}>{category.title}</Text>
          <Ionicons name="chevron-forward" size={18} color={theme.colors.gold} />
        </View>
        <Text style={styles.subtitle}>{category.subtitle}</Text>
        <View style={styles.footer}>
          <Text style={styles.gameName}>{category.gameName}</Text>
          <Text style={styles.score}>{score ? `${score}/100` : "Sin sesiones"}</Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    overflow: "hidden",
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.line,
    backgroundColor: theme.colors.surfaceElevated
  },
  pressed: {
    opacity: 0.82,
    transform: [{ scale: 0.99 }]
  },
  accent: {
    width: 4
  },
  body: {
    flex: 1,
    padding: theme.spacing.md
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: theme.spacing.sm
  },
  title: {
    color: theme.colors.text,
    fontSize: 16,
    fontWeight: "800",
    flex: 1
  },
  subtitle: {
    marginTop: theme.spacing.xs,
    color: theme.colors.textMuted,
    fontSize: 12
  },
  footer: {
    marginTop: theme.spacing.md,
    flexDirection: "row",
    justifyContent: "space-between"
  },
  gameName: {
    color: theme.colors.gold,
    fontSize: 12,
    fontWeight: "700"
  },
  score: {
    color: theme.colors.text,
    fontSize: 12,
    fontWeight: "700"
  }
});
