import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { ActivityIndicator, StyleSheet, View } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { LoginScreen } from "../screens/LoginScreen";
import { DashboardScreen } from "../screens/DashboardScreen";
import { AnalyticsScreen } from "../screens/AnalyticsScreen";
import { ConcentrationGame } from "../games/ConcentrationGame";
import { DividedAttentionGame } from "../games/DividedAttentionGame";
import { MemoryGame } from "../games/MemoryGame";
import { ProblemSolvingGame } from "../games/ProblemSolvingGame";
import { SelectiveAttentionGame } from "../games/SelectiveAttentionGame";
import { useAuth } from "../services/AuthContext";
import { theme } from "../utils/theme";
import { RootStackParamList } from "./types";

const Stack = createNativeStackNavigator<RootStackParamList>();

const navigationTheme = {
  ...DefaultTheme,
  dark: true,
  colors: {
    ...DefaultTheme.colors,
    background: theme.colors.background,
    card: theme.colors.background,
    text: theme.colors.text,
    border: theme.colors.line,
    primary: theme.colors.gold
  }
};

function LoadingGate() {
  return (
    <View style={styles.loading}>
      <ActivityIndicator color={theme.colors.gold} size="large" />
    </View>
  );
}

export function AppNavigator() {
  const { profile, loading } = useAuth();

  if (loading) {
    return <LoadingGate />;
  }

  return (
    <SafeAreaProvider>
      <NavigationContainer theme={navigationTheme}>
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
            contentStyle: {
              backgroundColor: theme.colors.background
            },
            animation: "fade_from_bottom"
          }}
        >
          {profile ? (
            <>
              <Stack.Screen name="Dashboard" component={DashboardScreen} />
              <Stack.Screen name="Analytics" component={AnalyticsScreen} />
              <Stack.Screen name="DividedAttentionGame" component={DividedAttentionGame} />
              <Stack.Screen name="ConcentrationGame" component={ConcentrationGame} />
              <Stack.Screen name="MemoryGame" component={MemoryGame} />
              <Stack.Screen name="SelectiveAttentionGame" component={SelectiveAttentionGame} />
              <Stack.Screen name="ProblemSolvingGame" component={ProblemSolvingGame} />
            </>
          ) : (
            <Stack.Screen name="Login" component={LoginScreen} />
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.colors.background
  }
});
