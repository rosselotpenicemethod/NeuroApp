import { Ionicons } from "@expo/vector-icons";
import { TextInput, TextInputProps, StyleSheet, View } from "react-native";
import { theme } from "../utils/theme";

type AppTextInputProps = TextInputProps & {
  icon: keyof typeof Ionicons.glyphMap;
};

export function AppTextInput({ icon, ...props }: AppTextInputProps) {
  return (
    <View style={styles.container}>
      <Ionicons name={icon} size={18} color={theme.colors.gold} />
      <TextInput
        placeholderTextColor={theme.colors.textMuted}
        autoCapitalize="none"
        autoCorrect={false}
        style={styles.input}
        {...props}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: 54,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.lineStrong,
    backgroundColor: theme.colors.surface,
    flexDirection: "row",
    alignItems: "center",
    gap: theme.spacing.sm,
    paddingHorizontal: theme.spacing.md
  },
  input: {
    flex: 1,
    color: theme.colors.text,
    fontSize: 15,
    minHeight: 52
  }
});
