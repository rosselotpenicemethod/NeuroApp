import { CognitiveCategory, CognitiveCategoryId, GameSessionResult, RadarPoint, StoredGameSession, WeeklyPoint } from "./types";

export const CATEGORIES: CognitiveCategory[] = [
  {
    id: "divided-attention",
    title: "Atencion Dividida",
    subtitle: "Respuesta dual visual + textual",
    gameName: "Dual Load",
    accent: "#D8B35F"
  },
  {
    id: "concentration",
    title: "Concentracion",
    subtitle: "Sustained attention task",
    gameName: "Sustain X",
    accent: "#6BA6FF"
  },
  {
    id: "memory",
    title: "Memoria",
    subtitle: "N-back visual progresivo",
    gameName: "Grid Recall",
    accent: "#70D6A3"
  },
  {
    id: "selective-attention",
    title: "Atencion Selectiva",
    subtitle: "Inhibicion ante distractores",
    gameName: "Target Filter",
    accent: "#B58CFF"
  },
  {
    id: "problem-solving",
    title: "Resolucion de Problemas",
    subtitle: "Matrices logicas abstractas",
    gameName: "Logic Matrix",
    accent: "#EF7777"
  }
];

export const categoryById = (id: CognitiveCategoryId) => CATEGORIES.find((category) => category.id === id);

export const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max);

export const average = (values: number[]) => {
  if (values.length === 0) {
    return 0;
  }
  return values.reduce((sum, value) => sum + value, 0) / values.length;
};

export const roundMetric = (value: number) => Math.round(value * 10) / 10;

export const scoreFromAccuracySpeed = (accuracy: number, reactionTimeMs: number, penalty = 0) => {
  const accuracyScore = clamp(accuracy, 0, 1) * 70;
  const speedScore = clamp((1600 - reactionTimeMs) / 1200, 0, 1) * 30;
  return Math.round(clamp(accuracyScore + speedScore - penalty, 0, 100));
};

export const buildSession = (result: Omit<GameSessionResult, "createdAt">): GameSessionResult => ({
  ...result,
  score: Math.round(clamp(result.score, 0, 100)),
  reactionTimeMs: Math.round(result.reactionTimeMs),
  errors: Math.max(0, Math.round(result.errors)),
  accuracy: roundMetric(clamp(result.accuracy, 0, 1) * 100),
  createdAt: new Date()
});

export const computeWeeklyEvolution = (sessions: StoredGameSession[]): WeeklyPoint[] => {
  const dayLabels = ["Lun", "Mar", "Mie", "Jue", "Vie", "Sab", "Dom"];
  const today = new Date();
  const monday = new Date(today);
  const day = monday.getDay() === 0 ? 7 : monday.getDay();
  monday.setDate(monday.getDate() - day + 1);
  monday.setHours(0, 0, 0, 0);

  return dayLabels.map((label, index) => {
    const start = new Date(monday);
    start.setDate(monday.getDate() + index);
    const end = new Date(start);
    end.setDate(start.getDate() + 1);
    const scores = sessions
      .filter((session) => session.createdAt >= start && session.createdAt < end)
      .map((session) => session.score);
    return {
      label,
      score: Math.round(average(scores))
    };
  });
};

export const computeMonthlyProgress = (sessions: StoredGameSession[]) => {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const scores = sessions.filter((session) => session.createdAt >= monthStart).map((session) => session.score);
  return Math.round(average(scores));
};

export const computeRadar = (sessions: StoredGameSession[]): RadarPoint[] =>
  CATEGORIES.map((category) => {
    const scores = sessions
      .filter((session) => session.category === category.id)
      .slice(0, 8)
      .map((session) => session.score);

    return {
      category: category.id,
      label: category.title.replace("Atencion ", "A. "),
      value: Math.round(average(scores))
    };
  });
