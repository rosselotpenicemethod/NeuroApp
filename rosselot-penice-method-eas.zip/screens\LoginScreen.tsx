import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useMemo, useState } from "react";
import { KeyboardAvoidingView, Platform, StyleSheet, Text, View } from "react-native";
import Animated, { FadeInUp } from "react-native-reanimated";
import { AppButton } from "../components/AppButton";
import { AppTextInput } from "../components/AppTextInput";
import { BrandLogo } from "../components/BrandLogo";
import { ScreenShell } from "../components/ScreenShell";
import { firebaseIsConfigured } from "../firebase/firebaseConfig";
import { RootStackParamList } from "../navigation/types";
import { useAuth } from "../services/AuthContext";
import { theme } from "../utils/theme";
import { validateEmail, validatePassword } from "../utils/validators";

type Props = NativeStackScreenProps<RootStackParamList, "Login">;

export function LoginScreen(_: Props) {
  const { signIn, resetPassword } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canSubmit = useMemo(() => validateEmail(email) && validatePassword(password), [email, password]);

  const handleLogin = async () => {
    setError(null);
    setMessage(null);

    if (!validateEmail(email)) {
      setError("Ingresa un email valido.");
      return;
    }
    if (!validatePassword(password)) {
      setError("La contrasena debe tener al menos 8 caracteres.");
      return;
    }

    setLoading(true);
    try {
      await signIn(email, password);
    } catch (loginError) {
      const text = loginError instanceof Error ? loginError.message : "No fue posible ingresar.";
      setError(text);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    setError(null);
    setMessage(null);
    if (!validateEmail(email)) {
      setError("Escribe tu email para recuperar la contrasena.");
      return;
    }
    try {
      await resetPassword(email);
      setMessage("Email de recuperacion enviado.");
    } catch {
      setError("No se pudo enviar la recuperacion.");
    }
  };

  return (
    <ScreenShell scroll={false}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.keyboard}>
        <View style={styles.logoZone}>
          <BrandLogo />
        </View>

        <Animated.View entering={FadeInUp.delay(160).duration(600)} style={styles.panel}>
          <Text style={styles.sectionTitle}>Acceso privado</Text>
          <Text style={styles.sectionCopy}>Usuarios autorizados por Firebase Authentication y Firestore.</Text>

          {!firebaseIsConfigured ? (
            <Text style={styles.warning}>Configura las variables EXPO_PUBLIC_FIREBASE_* antes de compilar.</Text>
          ) : null}

          <View style={styles.form}>
            <AppTextInput
              icon="mail-outline"
              placeholder="Email"
              keyboardType="email-address"
              value={email}
              onChangeText={setEmail}
              textContentType="emailAddress"
            />
            <AppTextInput
              icon="lock-closed-outline"
              placeholder="Contrasena"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              textContentType="password"
            />
            {error ? <Text style={styles.error}>{error}</Text> : null}
            {message ? <Text style={styles.success}>{message}</Text> : null}
            <AppButton title="Ingresar" icon="enter-outline" onPress={handleLogin} loading={loading} disabled={!canSubmit} />
            <AppButton title="Recuperar contrasena" icon="key-outline" variant="ghost" onPress={handleReset} />
          </View>
        </Animated.View>
      </KeyboardAvoidingView>
    </ScreenShell>
  );
}

const styles = StyleSheet.create({
  keyboard: {
    flex: 1,
    justifyContent: "space-between"
  },
  logoZone: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingTop: theme.spacing.xl
  },
  panel: {
    gap: theme.spacing.sm,
    paddingBottom: theme.spacing.xl
  },
  sectionTitle: {
    color: theme.colors.text,
    fontSize: theme.typography.h1,
    fontWeight: "900"
  },
  sectionCopy: {
    color: theme.colors.textMuted,
    fontSize: theme.typography.body,
    lineHeight: 21
  },
  warning: {
    color: theme.colors.warning,
    fontSize: 12,
    lineHeight: 17
  },
  form: {
    marginTop: theme.spacing.md,
    gap: theme.spacing.md
  },
  error: {
    color: theme.colors.danger,
    fontSize: 12,
    fontWeight: "700"
  },
  success: {
    color: theme.colors.success,
    fontSize: 12,
    fontWeight: "700"
  }
});
