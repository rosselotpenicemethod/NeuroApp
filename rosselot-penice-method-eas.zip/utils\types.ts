export type CognitiveCategoryId =
  | "divided-attention"
  | "concentration"
  | "memory"
  | "selective-attention"
  | "problem-solving";

export type CognitiveMetricKey =
  | "reactionTime"
  | "accuracy"
  | "errors"
  | "inhibition"
  | "consistency"
  | "fatigue"
  | "level";

export type CognitiveCategory = {
  id: CognitiveCategoryId;
  title: string;
  subtitle: string;
  gameName: string;
  accent: string;
};

export type GameSessionResult = {
  category: CognitiveCategoryId;
  categoryLabel: string;
  score: number;
  reactionTimeMs: number;
  errors: number;
  accuracy: number;
  metrics: Record<string, number>;
  createdAt: Date;
};

export type StoredGameSession = GameSessionResult & {
  id: string;
};

export type WeeklyPoint = {
  label: string;
  score: number;
};

export type RadarPoint = {
  category: CognitiveCategoryId;
  label: string;
  value: number;
};
