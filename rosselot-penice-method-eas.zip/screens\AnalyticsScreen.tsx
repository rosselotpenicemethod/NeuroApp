import { useFocusEffect } from "@react-navigation/native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useCallback, useMemo, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { AppButton } from "../components/AppButton";
import { CognitiveRadar } from "../components/CognitiveRadar";
import { MetricCard } from "../components/MetricCard";
import { ProgressBars } from "../components/ProgressBars";
import { ScreenShell } from "../components/ScreenShell";
import { RootStackParamList } from "../navigation/types";
import { fetchUserSessions } from "../services/analyticsService";
import { useAuth } from "../services/AuthContext";
import { average, computeMonthlyProgress, computeRadar, computeWeeklyEvolution } from "../utils/cognitive";
import { theme } from "../utils/theme";
import { StoredGameSession } from "../utils/types";

type Props = NativeStackScreenProps<RootStackParamList, "Analytics">;

export function AnalyticsScreen({ navigation }: Props) {
  const { profile } = useAuth();
  const [sessions, setSessions] = useState<StoredGameSession[]>([]);
  const [loading, setLoading] = useState(true);

  useFocusEffect(
    useCallback(() => {
      let mounted = true;
      setLoading(true);
      if (!profile) {
        return;
      }
      fetchUserSessions(profile.uid, 160)
        .then((data) => {
          if (mounted) {
            setSessions(data);
          }
        })
        .finally(() => {
          if (mounted) {
            setLoading(false);
          }
        });
      return () => {
        mounted = false;
      };
    }, [profile])
  );

  const weekly = useMemo(() => computeWeeklyEvolution(sessions), [sessions]);
  const radar = useMemo(() => computeRadar(sessions), [sessions]);
  const monthly = useMemo(() => computeMonthlyProgress(sessions), [sessions]);
  const lastTenAverage = useMemo(() => Math.round(average(sessions.slice(0, 10).map((session) => session.score))), [sessions]);
  const reactionAverage = useMemo(
    () => Math.round(average(sessions.slice(0, 20).map((session) => session.reactionTimeMs))),
    [sessions]
  );
  const best = useMemo(() => sessions.slice().sort((a, b) => b.score - a.score).slice(0, 5), [sessions]);

  return (
    <ScreenShell>
      <View style={styles.header}>
        <AppButton title="Volver" icon="chevron-back" variant="ghost" onPress={() => navigation.goBack()} style={styles.back} />
        <View style={styles.headerText}>
          <Text style={styles.kicker}>ANALYTICS</Text>
          <Text style={styles.title}>Progreso historico</Text>
        </View>
      </View>

      {loading ? (
        <ActivityIndicator color={theme.colors.gold} />
      ) : (
        <View style={styles.body}>
          <View style={styles.grid}>
            <MetricCard label="Promedio ultimas 10" value={`${lastTenAverage}/100`} />
            <MetricCard label="Progreso mensual" value={`${monthly}/100`} />
            <MetricCard label="Reaccion media" value={`${reactionAverage || 0} ms`} tone={theme.colors.blue} />
          </View>

          <View style={styles.block}>
            <Text style={styles.blockTitle}>Evolucion semanal</Text>
            <ProgressBars points={weekly} />
          </View>

          <View style={styles.block}>
            <Text style={styles.blockTitle}>Radar cognitivo</Text>
            <CognitiveRadar points={radar} />
          </View>

          <View style={styles.block}>
            <Text style={styles.blockTitle}>Ranking personal</Text>
            {best.length === 0 ? (
              <Text style={styles.empty}>Aun no hay sesiones registradas.</Text>
            ) : (
              best.map((session, index) => (
                <View key={session.id} style={styles.rankRow}>
                  <Text style={styles.rankIndex}>#{index + 1}</Text>
                  <View style={styles.rankBody}>
                    <Text style={styles.rankTitle}>{session.categoryLabel}</Text>
                    <Text style={styles.rankDate}>{session.createdAt.toLocaleDateString()}</Text>
                  </View>
                  <Text style={styles.rankScore}>{session.score}</Text>
                </View>
              ))
            )}
          </View>
        </View>
      )}
    </ScreenShell>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.lg
  },
  back: {
    width: 96,
    height: 42
  },
  headerText: {
    flex: 1
  },
  kicker: {
    color: theme.colors.gold,
    fontSize: 11,
    fontWeight: "900"
  },
  title: {
    color: theme.colors.text,
    fontSize: 25,
    fontWeight: "900"
  },
  body: {
    gap: theme.spacing.lg
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.md
  },
  block: {
    padding: theme.spacing.md,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.line,
    backgroundColor: theme.colors.surfaceElevated
  },
  blockTitle: {
    color: theme.colors.text,
    fontSize: theme.typography.h2,
    fontWeight: "900",
    marginBottom: theme.spacing.md
  },
  empty: {
    color: theme.colors.textMuted
  },
  rankRow: {
    minHeight: 58,
    flexDirection: "row",
    alignItems: "center",
    gap: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.line
  },
  rankIndex: {
    color: theme.colors.gold,
    fontSize: 14,
    fontWeight: "900",
    width: 34
  },
  rankBody: {
    flex: 1
  },
  rankTitle: {
    color: theme.colors.text,
    fontSize: 14,
    fontWeight: "800"
  },
  rankDate: {
    color: theme.colors.textMuted,
    fontSize: 11,
    marginTop: 2
  },
  rankScore: {
    color: theme.colors.text,
    fontSize: 20,
    fontWeight: "900"
  }
});
