import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useEffect, useRef, useState } from "react";
import { Dimensions, StyleSheet, Text, View } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from "react-native-reanimated";
import { AppButton } from "../components/AppButton";
import { MetricCard } from "../components/MetricCard";
import { RootStackParamList } from "../navigation/types";
import { average, scoreFromAccuracySpeed } from "../utils/cognitive";
import { theme } from "../utils/theme";
import { GameFrame } from "./GameFrame";
import { GameSummary } from "./GameSummary";
import { useSessionRecorder } from "./useSessionRecorder";

type Props = NativeStackScreenProps<RootStackParamList, "DividedAttentionGame">;

type Trial = {
  visualTarget: boolean;
  textTarget: boolean;
  text: string;
  startedAt: number;
  visualAnswered: boolean;
  textAnswered: boolean;
};

const MAX_TRIALS = 18;
const TEXT_STREAM = ["ALFA", "BRAVO", "FOCUS", "VECTOR", "FOCUS", "NEXUS", "DELTA"];

export function DividedAttentionGame({ navigation }: Props) {
  const { result, saved, saveError, completeSession, resetSession } = useSessionRecorder();
  const [running, setRunning] = useState(false);
  const [trialIndex, setTrialIndex] = useState(0);
  const [trial, setTrial] = useState<Trial | null>(null);
  const [hits, setHits] = useState(0);
  const [errors, setErrors] = useState(0);
  const [dualErrors, setDualErrors] = useState(0);
  const reactionTimes = useRef<number[]>([]);
  const trialRef = useRef<Trial | null>(null);
  const completedRef = useRef(false);
  const x = useSharedValue(16);
  const y = useSharedValue(22);
  const width = Dimensions.get("window").width - 72;

  const targetStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: x.value }, { translateY: y.value }]
  }));

  const createTrial = () => {
    const next: Trial = {
      visualTarget: Math.random() > 0.55,
      textTarget: Math.random() > 0.62,
      text: TEXT_STREAM[Math.floor(Math.random() * TEXT_STREAM.length)],
      startedAt: Date.now(),
      visualAnswered: false,
      textAnswered: false
    };
    if (next.text === "FOCUS") {
      next.textTarget = true;
    }
    trialRef.current = next;
    setTrial(next);
    x.value = withTiming(Math.random() * Math.max(width - 56, 120), { duration: 420 });
    y.value = withTiming(Math.random() * 120, { duration: 420 });
  };

  const finish = async () => {
    if (completedRef.current) {
      return;
    }
    completedRef.current = true;
    setRunning(false);
    const totalSignals = MAX_TRIALS * 2;
    const accuracy = hits / totalSignals;
    const reactionTimeMs = average(reactionTimes.current) || 1200;
    await completeSession({
      category: "divided-attention",
      categoryLabel: "Atencion Dividida",
      score: scoreFromAccuracySpeed(accuracy, reactionTimeMs, dualErrors * 1.8),
      reactionTimeMs,
      errors,
      accuracy,
      metrics: {
        dualTaskErrors: dualErrors,
        visualTextAccuracy: accuracy * 100,
        correctResponses: hits
      }
    });
  };

  useEffect(() => {
    if (!running || result) {
      return undefined;
    }
    if (trialIndex >= MAX_TRIALS) {
      void finish();
      return undefined;
    }
    createTrial();
    const timeout = setTimeout(() => {
      const current = trialRef.current;
      if (!current) {
        return;
      }
      let omissions = 0;
      if (current.visualTarget && !current.visualAnswered) {
        omissions += 1;
      }
      if (current.textTarget && !current.textAnswered) {
        omissions += 1;
      }
      if (omissions > 0) {
        setErrors((value) => value + omissions);
        setDualErrors((value) => value + (current.visualTarget && current.textTarget ? omissions : 0));
      }
      setTrialIndex((value) => value + 1);
    }, 1750);
    return () => clearTimeout(timeout);
  }, [running, trialIndex, result]);

  const start = () => {
    resetSession();
    completedRef.current = false;
    reactionTimes.current = [];
    setHits(0);
    setErrors(0);
    setDualErrors(0);
    setTrialIndex(0);
    setRunning(true);
  };

  const answer = (channel: "visual" | "text") => {
    const current = trialRef.current;
    if (!current || !running) {
      return;
    }
    const target = channel === "visual" ? current.visualTarget : current.textTarget;
    const answeredKey = channel === "visual" ? "visualAnswered" : "textAnswered";
    if (current[answeredKey]) {
      return;
    }
    current[answeredKey] = true;
    if (target) {
      reactionTimes.current.push(Date.now() - current.startedAt);
      setHits((value) => value + 1);
    } else {
      setErrors((value) => value + 1);
      setDualErrors((value) => value + 1);
    }
    setTrial({ ...current });
  };

  if (result) {
    return (
      <GameFrame title="Atencion Dividida" subtitle="Respuesta simultanea visual y textual" onBack={() => navigation.goBack()}>
        <GameSummary result={result} saved={saved} saveError={saveError} onRestart={start} onDashboard={() => navigation.navigate("Dashboard")} />
      </GameFrame>
    );
  }

  return (
    <GameFrame title="Atencion Dividida" subtitle="Toca solo cuando el canal sea target" onBack={() => navigation.goBack()}>
      <View style={styles.metrics}>
        <MetricCard label="Trial" value={`${Math.min(trialIndex + 1, MAX_TRIALS)}/${MAX_TRIALS}`} />
        <MetricCard label="Aciertos" value={hits} tone={theme.colors.success} />
        <MetricCard label="Errores dual" value={dualErrors} tone={theme.colors.danger} />
      </View>

      <View style={styles.arena}>
        <Animated.View style={[styles.stimulus, trial?.visualTarget && styles.visualTarget, targetStyle]} />
      </View>

      <View style={styles.textStream}>
        <Text style={styles.textLabel}>Canal textual</Text>
        <Text style={[styles.streamValue, trial?.textTarget && styles.targetText]}>{trial?.text ?? "LISTO"}</Text>
      </View>

      <View style={styles.actions}>
        {!running ? (
          <AppButton title="Iniciar sesion" icon="play-outline" onPress={start} />
        ) : (
          <>
            <AppButton title="Visual target" icon="radio-button-on-outline" onPress={() => answer("visual")} />
            <AppButton title="Texto target" icon="text-outline" variant="ghost" onPress={() => answer("text")} />
          </>
        )}
      </View>
    </GameFrame>
  );
}

const styles = StyleSheet.create({
  metrics: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.md,
    marginBottom: theme.spacing.lg
  },
  arena: {
    height: 208,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.lineStrong,
    backgroundColor: theme.colors.surface,
    overflow: "hidden"
  },
  stimulus: {
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 2,
    borderColor: theme.colors.textMuted,
    backgroundColor: "#151515"
  },
  visualTarget: {
    borderColor: theme.colors.gold,
    backgroundColor: "#3B2F12"
  },
  textStream: {
    marginTop: theme.spacing.lg,
    padding: theme.spacing.lg,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surfaceElevated,
    borderWidth: 1,
    borderColor: theme.colors.line
  },
  textLabel: {
    color: theme.colors.textMuted,
    fontSize: 11,
    fontWeight: "800"
  },
  streamValue: {
    color: theme.colors.text,
    fontSize: 34,
    fontWeight: "900",
    marginTop: theme.spacing.xs,
    textAlign: "center"
  },
  targetText: {
    color: theme.colors.gold
  },
  actions: {
    marginTop: theme.spacing.lg,
    gap: theme.spacing.md
  }
});
