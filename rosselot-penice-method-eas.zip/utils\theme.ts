export const theme = {
  colors: {
    background: "#050505",
    surface: "#0B0B0D",
    surfaceElevated: "#121215",
    line: "#242428",
    lineStrong: "#3C3525",
    gold: "#D8B35F",
    goldMuted: "#8F7440",
    platinum: "#E8E4D8",
    text: "#F5F1E8",
    textMuted: "#9E9A90",
    danger: "#DD6B6B",
    success: "#5ED49A",
    warning: "#E8B451",
    blue: "#6BA6FF",
    green: "#70D6A3",
    red: "#EF7777",
    violet: "#B58CFF"
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 14,
    lg: 20,
    xl: 28,
    xxl: 40
  },
  radius: {
    sm: 6,
    md: 8,
    lg: 12
  },
  typography: {
    title: 30,
    h1: 24,
    h2: 18,
    body: 15,
    small: 12,
    micro: 10
  }
} as const;

export type AppTheme = typeof theme;
